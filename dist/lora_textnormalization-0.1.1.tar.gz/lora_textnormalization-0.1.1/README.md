# import

`from lora_textnormalization import spacy_process`

# Usage

`normalized = spacy_process("Markov's long text")`

# Output

`list['Markov', 'long', 'text']`
